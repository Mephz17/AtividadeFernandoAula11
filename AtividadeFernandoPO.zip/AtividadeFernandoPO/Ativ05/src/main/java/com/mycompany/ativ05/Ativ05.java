/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ativ05;

/**
 *
 * @author iagom
 */
public class Ativ05 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
